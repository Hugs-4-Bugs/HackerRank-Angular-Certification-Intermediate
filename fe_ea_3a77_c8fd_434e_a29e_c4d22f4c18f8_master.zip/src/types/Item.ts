export interface Item {
  name: string;
  genre: string;
  creator: string;
  type: string;
  totalTime?: number;
}
