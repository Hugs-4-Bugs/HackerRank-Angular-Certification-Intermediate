import { Component } from '@angular/core';
import { Item } from "../types/Item";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  bookList: Item[] = []; // Ensure this is correctly initialized as an array of Item
  songList: Item[] = []; // Ensure this is correctly initialized as an array of Item

  onItemAdded(item: Item) {
    if (item.type === 'Book') {
      this.bookList.push(item);
    } else if (item.type === 'Song') {
      this.songList.push(item);
    }
  }

  onItemDelete(item: Item) {
    if (item.type === 'Book') {
      this.bookList = this.bookList.filter(i => i !== item);
    } else if (item.type === 'Song') {
      this.songList = this.songList.filter(i => i !== item);
    }
  }
}
